device_config = {"led_pin":2,
"useWiFi":True
}

wifi_config = {"ssid":"",
"password":""
}

google_cloud_config = {"project_id":"ourprobes-258320",
"cloud_region":"us-central1",
"registry_id":"microcontroller",
"device_id":"D9999",
"mqtt_bridge_hostname":"mqtt.googleapis.com",
"mqtt_bridge_port":8883
}

jwt_config = {"algorithm":"RS256",
"token_ttl":43200,
"private_key":()
}